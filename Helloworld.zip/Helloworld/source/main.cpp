#include"../headers/helloworld.h"
#include<stdlib.h>
int main()
{
  helloworld();
  system("pause");
}